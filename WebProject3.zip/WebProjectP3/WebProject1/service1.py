
from flask import Flask, request
import io
import numpy as np
import json

app = Flask(__name__)

@app.route('/')
@app.route('/node_similarity')
def node_similarity():
    input = request.args.get('input', '')

    try:
        # convert string to file-like object io.StringIO 
        csv_file = io.StringIO(input)
        
        # read np_array matrix
        matrix = np.genfromtxt(csv_file, delimiter=",")

        # find V0 and V1 neighbors
        neighbors_dict = {}
        for vertex in range(2):
            neighbors = []
            for i, is_neighbor in enumerate(matrix[vertex]):
                if is_neighbor == 1:
                    neighbors.append(i)
            neighbors_dict[vertex] = neighbors

        # find intersection and union
        intersection = set(neighbors_dict[0]).intersection(neighbors_dict[1])
        union = set(neighbors_dict[0]).union(neighbors_dict[1])
        # union should not include V0 and V1
        union_without_themselves = union
        union_without_themselves.remove(0)
        union_without_themselves.remove(1)
        # calculate similarity
        similarity = len(intersection) / len(union_without_themselves)

        result_string = similarity
        json_object = json.loads(result_string)
        return json.dumps(json_object, indent=4)
    
    except ValueError:
        return "Please input a string"

    

if __name__ == '__main__':
    app.run('localhost', 4449)


