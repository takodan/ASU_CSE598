
from flask import Flask, request
import io
import numpy as np
import json

app = Flask(__name__)

@app.route('/')
@app.route('/community_density')
def community_density():
    input = request.args.get('input', '')

    try:
        # convert string to file-like object io.StringIO 
        csv_file = io.StringIO(input)
        
        # read np_array matrix
        matrix = np.genfromtxt(csv_file, delimiter=",")


        # ensure the matrix is square
        assert matrix.shape[0] == matrix.shape[1], "matrix is not square"
        
        # number of vertices
        n = matrix.shape[0]
        
        # number of edges
        m = np.sum(matrix) / 2
        
        # possible number of edges
        possible_edges = n * (n - 1) / 2
        
        # calculate the community density
        density = m / possible_edges if possible_edges != 0 else 0

        # convert to float
        density = float(density)

        result_string = density
        json_object = json.loads(result_string)
        return json.dumps(json_object, indent=4)
    
    except ValueError:
        return "Please input a string"

    

if __name__ == '__main__':
    app.run('localhost', 4449)


