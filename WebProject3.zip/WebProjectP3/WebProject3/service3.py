
from flask import Flask, request
import io
import numpy as np
import json

app = Flask(__name__)

@app.route('/')
@app.route('/content_based_recommendation')
def content_based_recommendation():
    input = request.args.get('input', '')

    try:
        # convert string to file-like object io.StringIO 
        csv_file = io.StringIO(input)
        
        # read np_array matrix
        matrix = np.genfromtxt(csv_file, delimiter=",")


        vector1 = matrix[0]
        vector2 = matrix[1]
        # calculate dot product
        dot_product = np.dot(vector1, vector2)
        # calculate L2 norm
        norm_vector1 = np.linalg.norm(vector1)
        norm_vector2 = np.linalg.norm(vector2)
        # calculate cosine similarity
        cosine_sim = dot_product / (norm_vector1 * norm_vector2)
        # convert to float
        cosine_sim = float(cosine_sim)

        result_string = cosine_sim
        json_object = json.loads(result_string)
        return json.dumps(json_object, indent=4)
    
    except ValueError:
        return "Please input a string"

    

if __name__ == '__main__':
    app.run('localhost', 4449)


