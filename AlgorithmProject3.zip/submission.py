import numpy as np
import networkx as nx
import copy
import math
import itertools


# Please do not modify.
def readData(fn):
    matrix = np.loadtxt(open(fn, "rb"), delimiter=",", skiprows=0)
    return matrix


def is_clique(matrix, vertices):
    # check if the given vertices are a clique
    for i in range(len(vertices)):
        for j in range(i + 1, len(vertices)):
            # check every edges between vertices, if equal zero, it is not a clique
            if matrix[vertices[i]][vertices[j]] == 0:
                return False
            
    return True


def maxClique(matrix):
    # Q1.1
    # The returned result is in string format. The returned node should start with an index of 0.
    # Each sub-community should be in an ascending order

    n = len(matrix)
    max_clique = []
    # check all subsets is a clique
    for i in range(1, n + 1):
        for vertices in itertools.combinations(range(n), i):
            if is_clique(matrix, vertices):
                # is a clique, check is bigger then max_clique
                if len(vertices) > len(max_clique):
                    max_clique = vertices

    # # matrix output if start from 1 and is string
    # max_clique = ", ".join(map(str, list(i + 1 for i in max_clique)))
    # matrix string output
    max_clique = ", ".join(map(str, list(i  for i in max_clique)))
    return max_clique


def CPM(matrix,k):
    # Q1.2
    # The returned result is in string format. The returned node should start with an index of 0.

    # find k_cliques
    n = len(matrix)
    k_cliques = []

    # check all subsets is a clique and size equal k
    for i in range(1, n + 1):
        for vertices in itertools.combinations(range(n), i):
            if len(vertices) == k and is_clique(matrix, vertices):
                    k_cliques.append(vertices)
    # merge cliques if they have k - 1 shared vertices
    merged_cliques = []
    # convert to sets for intersection
    sets = [set(group) for group in k_cliques]
    while sets:
        current_set = sets.pop(0)
        merged_set = current_set
        # find every other cliques with or more then k - 1 intersections
        for other_set in sets[:]:
            if len(merged_set.intersection(other_set)) >= k - 1:
                merged_set = merged_set.union(other_set)
                sets.remove(other_set)

        merged_cliques.append(sorted(merged_set))

    string_result = [",".join(map(str, sublist)) for sublist in merged_cliques]
    string_result = "},{".join(string_result)

    return "{" + string_result + "}"



def node_similarity(matrix):
    # Q1.3
    # The returned result is in float format.

    # find V0 and V1 neighbors
    neighbors_dict = {}
    for vertex in range(2):
        neighbors = []
        for i, is_neighbor in enumerate(matrix[vertex]):
            if is_neighbor == 1:
                neighbors.append(i)
        neighbors_dict[vertex] = neighbors

    # find intersection and union
    intersection = set(neighbors_dict[0]).intersection(neighbors_dict[1])
    union = set(neighbors_dict[0]).union(neighbors_dict[1])
    # union should not include V0 and V1
    union_without_themselves = union
    union_without_themselves.remove(0)
    union_without_themselves.remove(1)
    # calculate similarity
    similarity = len(intersection) / len(union_without_themselves)

    return similarity


def modularity(matrix):
    # Q1.4
    # The returned result is in np.ndarray format.

    # ensure the matrix is square
    assert matrix.shape[0] == matrix.shape[1], "matrix is not square"
    
    # number of vertices
    n = matrix.shape[0]
    
    # number of edges
    m = np.sum(matrix) / 2
    
    # degree vector
    k = np.sum(matrix, axis=1)
    
    # initialize the modularity matrix
    modularity_matrix = np.zeros((n, n))
    
    # calculate the modularity matrix
    for i in range(n):
        for j in range(n):
            expected_weight = (k[i] * k[j]) / (2 * m)
            modularity_matrix[i, j] = matrix[i, j] - expected_weight

    # round to two decimal places
    modularity_matrix = np.round(modularity_matrix, 2)
            
    return modularity_matrix



def community_density(matrix):
    # Q1.4
    # The returned result is in float format.

    # ensure the matrix is square
    assert matrix.shape[0] == matrix.shape[1], "matrix is not square"
    
    # number of vertices
    n = matrix.shape[0]
    
    # number of edges
    m = np.sum(matrix) / 2
    
    # possible number of edges
    possible_edges = n * (n - 1) / 2
    
    # calculate the community density
    density = m / possible_edges if possible_edges != 0 else 0

    # convert to float
    density = float(density)
    
    return density


def girvan_newman(matrix):
    # Q1.6
    # The returned result is in np.ndarray format.

    # use networkx
    # create a nx graph
    G = nx.Graph()

    # add nodes
    num_nodes = len(matrix)
    G.add_nodes_from(range(num_nodes))

    # add edges
    for i in range(num_nodes):
        for j in range(i + 1, num_nodes):
            if matrix[i][j] == 1:
                G.add_edge(i, j)

    # calculate edge betweenness centrality
    edge_betweenness = nx.edge_betweenness_centrality(G, normalized = False)

    # create a matrix to store edge betweenness centrality
    betweenness_matrix = np.zeros((num_nodes, num_nodes))

    # fill the matrix with edge betweenness centrality
    for (u, v), betweenness in edge_betweenness.items():
        betweenness_matrix[u][v] = np.round(betweenness)
        betweenness_matrix[v][u] = np.round(betweenness)

    return betweenness_matrix


def max_cascade(matrix, threshold=0.5,k=1):
    num_nodes = matrix.shape[0]

    def spread(matrix, seed):
        # node is activated
        # print("!!!seed=", seed,)
        activated = {seed}
        # first activated node is seed
        new_activated = {seed}
    
        # keep spread if there are new activated nodes
        while new_activated:
            # initialize next_activated node set
            next_activated = set()
            # print("--current_activated=", new_activated)
            # iterate new activated node and start spread
            for node in new_activated:
                # find node's neighbors
                # print("neighbors", np.where(matrix[node] > 0)[0])
                neighbors = np.where(matrix[node] > 0)[0]
                # print("neighbors", neighbors)
                # iterate neighbors
                for neighbor in neighbors:
                    # if neighbor not activated yet
                    if neighbor not in activated:
                        # if activate signal is greater then threshold
                        # print("neighbor", neighbor, f"matrix[{node}, {neighbor}]threshold", matrix[node, neighbor])
                        if threshold > matrix[node, neighbor]:
                            next_activated.add(neighbor)
                            # print("next_activated",next_activated)

            # next round, new_activated will be next_activated
            new_activated = next_activated
            # put new_activated into activated
            activated |= new_activated

        # print("!!seed=", seed, "activated=", activated, "len=", len(activated))

        # return size of activated node
        return len(activated)
    

    # find best node
    best_seeds = None
    # initialize best spread size
    best_spread = -1
    
    for node in range(num_nodes):
        # calculate node spread size
        current_spread = spread(matrix, node)
    
        if current_spread > best_spread:
            best_spread = current_spread
            best_seeds = node
    
    return best_seeds

def content_based_recommendation(matrix):
    # Q1.9
    # The returned result is in float format.
    
    vector1 = matrix[0]
    vector2 = matrix[1]
    # calculate dot product
    dot_product = np.dot(vector1, vector2)
    # calculate L2 norm
    norm_vector1 = np.linalg.norm(vector1)
    norm_vector2 = np.linalg.norm(vector2)
    # calculate cosine similarity
    cosine_sim = dot_product / (norm_vector1 * norm_vector2)
    # convert to float
    cosine_sim = float(cosine_sim)

    return cosine_sim


def cf_recommendation_k1(matrix):
    # Q1.10
    # The returned result is in float format.

    # find unknown items
    unknown_items = np.any(matrix == 9, axis=0)
    unknown_items_indices = np.where(unknown_items)[0][0]
    # print(unknown_items_indices)
    # find unknown user
    unknown_user = np.any(matrix == 9, axis=1)
    # calculate average ratings
    matrix_for_average = np.where(matrix == 9, np.nan, matrix)
    average_ratings = np.nanmean(matrix_for_average, axis=0)

    # delete unknown ratings
    cleaned_ratings = matrix[~unknown_user]

    # find unknown item ratings
    unknown_item_ratings = cleaned_ratings[:, unknown_items_indices]

    # find most similar item
    max_similarity = 0
    most_similar_item = -1
    # print(f"similarity with {unknown_items_indices}:")
    for i in range(cleaned_ratings.shape[1]):
        if i != unknown_items_indices:
            other_item_ratings = cleaned_ratings[:, i]
            similarity_matrix = np.vstack((unknown_item_ratings, other_item_ratings))
            # calculate cosine_similarity using content_based_recommendation
            similarity = content_based_recommendation(similarity_matrix)
            if similarity > max_similarity:
                max_similarity = similarity
                most_similar_item = i
            # print(f"  item {i}: {similarity}")
    #  print(f"most similar item: {most_similar_item}, similarity = {max_similarity:.4f}")

    similar_user_rating = matrix[unknown_user, most_similar_item]
    # print(f"  most similar item rating = {similar_user_rating[0]}")


    result = np.round(average_ratings[unknown_items] + (max_similarity*(similar_user_rating - average_ratings[most_similar_item])), 1)

    return float(result[0])